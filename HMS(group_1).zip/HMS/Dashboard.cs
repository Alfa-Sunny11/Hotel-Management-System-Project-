﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            uC_AddRoom3.Visible = true;
            uC_AddRoom3.BringToFront();
        }

        

        private void CustomerReg_Click(object sender, EventArgs e)
        {
            uC_CustomerReg1.Visible = true;
            uC_CustomerReg1.BringToFront();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            uC_Payment1.Visible = true;
            uC_Payment1.BringToFront();
        }

        private void Checkout_Click(object sender, EventArgs e)
        {
            uC_CustomerCheckOut1.Visible = true;
            uC_CustomerCheckOut1.BringToFront();
        }

        private void CustomerDetails_Click(object sender, EventArgs e)
        {
            uC_CustomerDetails1.Visible = true;
            uC_CustomerDetails1.BringToFront();
        }

        private void Employee_Click(object sender, EventArgs e)
        {
            uC_Employee1.Visible = true;
            uC_Employee1.BringToFront();
        }

        
        private void UtiltyInfo_Click(object sender, EventArgs e)
        {
            uC_UtilityInfo1.Visible = true;
            uC_UtilityInfo1.BringToFront();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            //  uC_AddRoom1.Visible = true;
            //    uC_CustomerReg1.Visible = false;
            //    uC_CustomerCheckOut1.Visible = false;
            //   uC_CustomerDetails1.Visible = false;
            //   uC_Employee1.Visible = false;
            //  uC_UtilityInfo1.Visible = false;

            btnAddRoom.PerformClick();
        }

        private void Dashboard_Load_1(object sender, EventArgs e)
        {

        }

        private void btnMini_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

      
    }
}
