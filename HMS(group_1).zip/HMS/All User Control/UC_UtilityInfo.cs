﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS.All_User_Control
{
    public partial class UC_UtilityInfo : UserControl
    {
        Function fn = new Function();
        String query;

        public UC_UtilityInfo()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtElectric.Text != "" && txtgenerator.Text != "" && txtInternet.Text != "" && txtOther.Text != "" && txtMonth.Text != "" && txtDate.Text != "")
            {
                Int64 electric = Int64.Parse(txtElectric.Text);
                Int64 generator = Int64.Parse(txtgenerator.Text);
                Int64 internet = Int64.Parse(txtInternet.Text);
                Int64 other = Int64.Parse(txtOther.Text);
                String month = txtMonth.Text;
                String date = txtDate.Text;
                String BillNo = txtBillno.Text;


                query = "insert into utility (electric_bill,generator_bill,internet_bill,other_bill,month,date,bill_no) values(" + electric + "," + generator + "," + internet + "," + other + ",'" + month + "','" + date + "','"+BillNo+"' ) ";
                fn.setData(query, "Register Successfully");
                clearAll();
            }
            else
            {
                MessageBox.Show("Fill All Fields", "Warning !!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

            
            private void tabUtility_SelectedIndexChanged(object sender, EventArgs e)
            {
                setutility(gunaDataGridView6);
            }

            public void setutility(DataGridView dgv)
            {
                query = "select * from utility";
                DataSet ds = fn.getData(query);
                dgv.DataSource = ds.Tables[0];
            }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            query = "select utility.electric_bill,utility.generator_bill,utility.internet_bill,utility.other_bill,utility.month,utility.date,utility.bill_no from utility where month like '" + txtSearch.Text + "'";
            DataSet ds = fn.getData(query);
            gunaDataGridView6.DataSource = ds.Tables[0];
        }

        private void UC_UtilityInfo_Leave(object sender, EventArgs e)
        {
            clearAll();
        }

        public void clearAll()
        {
            txtElectric.Clear();
            txtgenerator.Clear();
            txtInternet.Clear();
            txtOther.Clear();
            txtMonth.SelectedIndex = -1;
            txtDate.ResetText();
            txtBillno.Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Int64 electric = Int64.Parse(txtElectric.Text);
            Int64 generator = Int64.Parse(txtgenerator.Text);
            Int64 internet = Int64.Parse(txtInternet.Text);
            Int64 other = Int64.Parse(txtOther.Text);
            String month = txtMonth.Text;
            String date = txtDate.Text;
            String BillNo = txtBillno.Text;

            query = "update utility set electric_bill= " + electric + ",generator_bill=" + generator + ",internet_bill=" + internet + ",other_bill=" + other + ",month = '" + month + "',date='" + date + "',bill_no ='" + BillNo + "' where bill_no = '" + BillNo + "' ";
            fn.setData(query, "Update Successfully");
            clearAll();
        }
    }
}
