﻿namespace HMS.All_User_Control
{
    partial class UC_CustomerReg
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_CustomerReg));
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGender = new Guna.UI.WinForms.GunaComboBox();
            this.txtDob = new Guna.UI.WinForms.GunaDateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCheckin = new Guna.UI.WinForms.GunaDateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtBed = new Guna.UI.WinForms.GunaComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtRoom = new Guna.UI.WinForms.GunaComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRoomNo = new Guna.UI.WinForms.GunaComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnalloteroom = new Guna.UI.WinForms.GunaButton();
            this.txtName = new Guna.UI.WinForms.GunaLineTextBox();
            this.txtContact = new Guna.UI.WinForms.GunaLineTextBox();
            this.txtNationality = new Guna.UI.WinForms.GunaLineTextBox();
            this.txtIdprf = new Guna.UI.WinForms.GunaLineTextBox();
            this.txtAddress = new Guna.UI.WinForms.GunaLineTextBox();
            this.txtPrice = new Guna.UI.WinForms.GunaLineTextBox();
            this.gunaTransfarantPictureBox1 = new Guna.UI.WinForms.GunaTransfarantPictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCheckout = new Guna.UI.WinForms.GunaDateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.Radius = 25;
            this.gunaElipse1.TargetControl = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(360, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Customer registration";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Mobile No";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 263);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 23);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nationality";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 355);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 23);
            this.label5.TabIndex = 6;
            this.label5.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 442);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 23);
            this.label6.TabIndex = 7;
            this.label6.Text = "Date of Birth";
            // 
            // txtGender
            // 
            this.txtGender.BackColor = System.Drawing.Color.Transparent;
            this.txtGender.BaseColor = System.Drawing.Color.White;
            this.txtGender.BorderColor = System.Drawing.Color.Silver;
            this.txtGender.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtGender.FocusedColor = System.Drawing.Color.Empty;
            this.txtGender.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtGender.ForeColor = System.Drawing.Color.Black;
            this.txtGender.FormattingEnabled = true;
            this.txtGender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.txtGender.Location = new System.Drawing.Point(19, 381);
            this.txtGender.Name = "txtGender";
            this.txtGender.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtGender.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtGender.Size = new System.Drawing.Size(228, 31);
            this.txtGender.TabIndex = 11;
            // 
            // txtDob
            // 
            this.txtDob.BackColor = System.Drawing.Color.OrangeRed;
            this.txtDob.BaseColor = System.Drawing.Color.Coral;
            this.txtDob.BorderColor = System.Drawing.Color.Silver;
            this.txtDob.CustomFormat = null;
            this.txtDob.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtDob.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtDob.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDob.ForeColor = System.Drawing.Color.Black;
            this.txtDob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtDob.Location = new System.Drawing.Point(19, 468);
            this.txtDob.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtDob.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtDob.Name = "txtDob";
            this.txtDob.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtDob.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtDob.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtDob.OnPressedColor = System.Drawing.Color.Black;
            this.txtDob.Size = new System.Drawing.Size(228, 30);
            this.txtDob.TabIndex = 12;
            this.txtDob.Text = "10-Dec-20";
            this.txtDob.Value = new System.DateTime(2020, 12, 10, 11, 18, 41, 238);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(287, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 23);
            this.label10.TabIndex = 13;
            this.label10.Text = "ID Proof";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(287, 179);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(88, 23);
            this.label11.TabIndex = 14;
            this.label11.Text = "Address";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(287, 263);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 23);
            this.label12.TabIndex = 15;
            this.label12.Text = "Check in";
            // 
            // txtCheckin
            // 
            this.txtCheckin.BackColor = System.Drawing.Color.OrangeRed;
            this.txtCheckin.BaseColor = System.Drawing.Color.Coral;
            this.txtCheckin.BorderColor = System.Drawing.Color.Silver;
            this.txtCheckin.CustomFormat = null;
            this.txtCheckin.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtCheckin.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckin.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheckin.ForeColor = System.Drawing.Color.Black;
            this.txtCheckin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtCheckin.Location = new System.Drawing.Point(291, 289);
            this.txtCheckin.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtCheckin.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtCheckin.Name = "txtCheckin";
            this.txtCheckin.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtCheckin.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckin.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckin.OnPressedColor = System.Drawing.Color.Black;
            this.txtCheckin.Size = new System.Drawing.Size(245, 30);
            this.txtCheckin.TabIndex = 18;
            this.txtCheckin.Text = "10-Dec-20";
            this.txtCheckin.Value = new System.DateTime(2020, 12, 10, 11, 12, 34, 755);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(578, 355);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 23);
            this.label9.TabIndex = 23;
            this.label9.Text = "Price";
            // 
            // txtBed
            // 
            this.txtBed.BackColor = System.Drawing.Color.Transparent;
            this.txtBed.BaseColor = System.Drawing.Color.White;
            this.txtBed.BorderColor = System.Drawing.Color.Silver;
            this.txtBed.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtBed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtBed.FocusedColor = System.Drawing.Color.Empty;
            this.txtBed.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtBed.ForeColor = System.Drawing.Color.Black;
            this.txtBed.FormattingEnabled = true;
            this.txtBed.Items.AddRange(new object[] {
            "Single",
            "Double",
            "Triple"});
            this.txtBed.Location = new System.Drawing.Point(581, 117);
            this.txtBed.Name = "txtBed";
            this.txtBed.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtBed.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtBed.Size = new System.Drawing.Size(228, 31);
            this.txtBed.TabIndex = 26;
            this.txtBed.SelectedIndexChanged += new System.EventHandler(this.txtBed_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(577, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 23);
            this.label7.TabIndex = 25;
            this.label7.Text = "Bed";
            // 
            // txtRoom
            // 
            this.txtRoom.BackColor = System.Drawing.Color.Transparent;
            this.txtRoom.BaseColor = System.Drawing.Color.White;
            this.txtRoom.BorderColor = System.Drawing.Color.Silver;
            this.txtRoom.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtRoom.FocusedColor = System.Drawing.Color.Empty;
            this.txtRoom.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtRoom.ForeColor = System.Drawing.Color.Black;
            this.txtRoom.FormattingEnabled = true;
            this.txtRoom.Items.AddRange(new object[] {
            "Ac",
            "Non-Ac"});
            this.txtRoom.Location = new System.Drawing.Point(582, 205);
            this.txtRoom.Name = "txtRoom";
            this.txtRoom.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtRoom.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtRoom.Size = new System.Drawing.Size(228, 31);
            this.txtRoom.TabIndex = 28;
            this.txtRoom.SelectedIndexChanged += new System.EventHandler(this.txtRoom_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(578, 179);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 23);
            this.label8.TabIndex = 27;
            this.label8.Text = "Room Type";
            // 
            // txtRoomNo
            // 
            this.txtRoomNo.BackColor = System.Drawing.Color.Transparent;
            this.txtRoomNo.BaseColor = System.Drawing.Color.White;
            this.txtRoomNo.BorderColor = System.Drawing.Color.Silver;
            this.txtRoomNo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.txtRoomNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtRoomNo.FocusedColor = System.Drawing.Color.Empty;
            this.txtRoomNo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtRoomNo.ForeColor = System.Drawing.Color.Black;
            this.txtRoomNo.FormattingEnabled = true;
            this.txtRoomNo.Location = new System.Drawing.Point(581, 289);
            this.txtRoomNo.Name = "txtRoomNo";
            this.txtRoomNo.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtRoomNo.OnHoverItemForeColor = System.Drawing.Color.White;
            this.txtRoomNo.Size = new System.Drawing.Size(228, 31);
            this.txtRoomNo.TabIndex = 30;
            this.txtRoomNo.SelectedIndexChanged += new System.EventHandler(this.txtRoomNo_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(577, 263);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 23);
            this.label13.TabIndex = 29;
            this.label13.Text = "Room No";
            // 
            // btnalloteroom
            // 
            this.btnalloteroom.AnimationHoverSpeed = 0.07F;
            this.btnalloteroom.AnimationSpeed = 0.03F;
            this.btnalloteroom.BackColor = System.Drawing.Color.Transparent;
            this.btnalloteroom.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnalloteroom.BorderColor = System.Drawing.Color.Black;
            this.btnalloteroom.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnalloteroom.FocusedColor = System.Drawing.Color.Empty;
            this.btnalloteroom.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnalloteroom.ForeColor = System.Drawing.Color.White;
            this.btnalloteroom.Image = null;
            this.btnalloteroom.ImageSize = new System.Drawing.Size(20, 20);
            this.btnalloteroom.Location = new System.Drawing.Point(668, 442);
            this.btnalloteroom.Name = "btnalloteroom";
            this.btnalloteroom.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.btnalloteroom.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnalloteroom.OnHoverForeColor = System.Drawing.Color.White;
            this.btnalloteroom.OnHoverImage = null;
            this.btnalloteroom.OnPressedColor = System.Drawing.Color.Black;
            this.btnalloteroom.Radius = 25;
            this.btnalloteroom.Size = new System.Drawing.Size(159, 42);
            this.btnalloteroom.TabIndex = 31;
            this.btnalloteroom.Text = "Allote Room";
            this.btnalloteroom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnalloteroom.Click += new System.EventHandler(this.btnalloteroom_Click);
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.White;
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtName.LineColor = System.Drawing.Color.Gainsboro;
            this.txtName.Location = new System.Drawing.Point(19, 117);
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.SelectedText = "";
            this.txtName.Size = new System.Drawing.Size(228, 30);
            this.txtName.TabIndex = 32;
            // 
            // txtContact
            // 
            this.txtContact.BackColor = System.Drawing.Color.White;
            this.txtContact.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtContact.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtContact.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtContact.LineColor = System.Drawing.Color.Gainsboro;
            this.txtContact.Location = new System.Drawing.Point(19, 206);
            this.txtContact.Name = "txtContact";
            this.txtContact.PasswordChar = '\0';
            this.txtContact.SelectedText = "";
            this.txtContact.Size = new System.Drawing.Size(228, 30);
            this.txtContact.TabIndex = 33;
            // 
            // txtNationality
            // 
            this.txtNationality.BackColor = System.Drawing.Color.White;
            this.txtNationality.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNationality.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtNationality.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNationality.LineColor = System.Drawing.Color.Gainsboro;
            this.txtNationality.Location = new System.Drawing.Point(19, 290);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.PasswordChar = '\0';
            this.txtNationality.SelectedText = "";
            this.txtNationality.Size = new System.Drawing.Size(228, 30);
            this.txtNationality.TabIndex = 34;
            // 
            // txtIdprf
            // 
            this.txtIdprf.BackColor = System.Drawing.Color.White;
            this.txtIdprf.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtIdprf.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtIdprf.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtIdprf.LineColor = System.Drawing.Color.Gainsboro;
            this.txtIdprf.Location = new System.Drawing.Point(291, 118);
            this.txtIdprf.Name = "txtIdprf";
            this.txtIdprf.PasswordChar = '\0';
            this.txtIdprf.SelectedText = "";
            this.txtIdprf.Size = new System.Drawing.Size(228, 30);
            this.txtIdprf.TabIndex = 35;
            // 
            // txtAddress
            // 
            this.txtAddress.BackColor = System.Drawing.Color.White;
            this.txtAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAddress.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtAddress.LineColor = System.Drawing.Color.Gainsboro;
            this.txtAddress.Location = new System.Drawing.Point(291, 205);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.PasswordChar = '\0';
            this.txtAddress.SelectedText = "";
            this.txtAddress.Size = new System.Drawing.Size(228, 30);
            this.txtAddress.TabIndex = 36;
            // 
            // txtPrice
            // 
            this.txtPrice.BackColor = System.Drawing.Color.White;
            this.txtPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPrice.FocusedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtPrice.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPrice.LineColor = System.Drawing.Color.Gainsboro;
            this.txtPrice.Location = new System.Drawing.Point(581, 382);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.PasswordChar = '\0';
            this.txtPrice.SelectedText = "";
            this.txtPrice.Size = new System.Drawing.Size(228, 30);
            this.txtPrice.TabIndex = 37;
            // 
            // gunaTransfarantPictureBox1
            // 
            this.gunaTransfarantPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.gunaTransfarantPictureBox1.BaseColor = System.Drawing.Color.Black;
            this.gunaTransfarantPictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gunaTransfarantPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaTransfarantPictureBox1.Image")));
            this.gunaTransfarantPictureBox1.Location = new System.Drawing.Point(394, 23);
            this.gunaTransfarantPictureBox1.Name = "gunaTransfarantPictureBox1";
            this.gunaTransfarantPictureBox1.Size = new System.Drawing.Size(46, 39);
            this.gunaTransfarantPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaTransfarantPictureBox1.TabIndex = 38;
            this.gunaTransfarantPictureBox1.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(287, 355);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(117, 23);
            this.label14.TabIndex = 39;
            this.label14.Text = "Check Out";
            // 
            // txtCheckout
            // 
            this.txtCheckout.BackColor = System.Drawing.Color.OrangeRed;
            this.txtCheckout.BaseColor = System.Drawing.Color.Coral;
            this.txtCheckout.BorderColor = System.Drawing.Color.Silver;
            this.txtCheckout.CustomFormat = null;
            this.txtCheckout.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtCheckout.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckout.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheckout.ForeColor = System.Drawing.Color.Black;
            this.txtCheckout.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtCheckout.Location = new System.Drawing.Point(291, 382);
            this.txtCheckout.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtCheckout.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtCheckout.Name = "txtCheckout";
            this.txtCheckout.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtCheckout.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckout.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtCheckout.OnPressedColor = System.Drawing.Color.Black;
            this.txtCheckout.Size = new System.Drawing.Size(245, 30);
            this.txtCheckout.TabIndex = 40;
            this.txtCheckout.Text = "10-Dec-20";
            this.txtCheckout.Value = new System.DateTime(2020, 12, 10, 11, 12, 34, 755);
            // 
            // UC_CustomerReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtCheckout);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.gunaTransfarantPictureBox1);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtIdprf);
            this.Controls.Add(this.txtNationality);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.btnalloteroom);
            this.Controls.Add(this.txtRoomNo);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtRoom);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtBed);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtCheckin);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtDob);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UC_CustomerReg";
            this.Size = new System.Drawing.Size(883, 536);
            this.Leave += new System.EventHandler(this.UC_CustomerReg_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.gunaTransfarantPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Guna.UI.WinForms.GunaComboBox txtGender;
        private Guna.UI.WinForms.GunaButton btnalloteroom;
        private Guna.UI.WinForms.GunaComboBox txtRoomNo;
        private System.Windows.Forms.Label label13;
        private Guna.UI.WinForms.GunaComboBox txtRoom;
        private System.Windows.Forms.Label label8;
        private Guna.UI.WinForms.GunaComboBox txtBed;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private Guna.UI.WinForms.GunaDateTimePicker txtCheckin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private Guna.UI.WinForms.GunaDateTimePicker txtDob;
        private Guna.UI.WinForms.GunaLineTextBox txtPrice;
        private Guna.UI.WinForms.GunaLineTextBox txtAddress;
        private Guna.UI.WinForms.GunaLineTextBox txtIdprf;
        private Guna.UI.WinForms.GunaLineTextBox txtNationality;
        private Guna.UI.WinForms.GunaLineTextBox txtContact;
        private Guna.UI.WinForms.GunaLineTextBox txtName;
        private Guna.UI.WinForms.GunaTransfarantPictureBox gunaTransfarantPictureBox1;
        private System.Windows.Forms.Label label14;
        private Guna.UI.WinForms.GunaDateTimePicker txtCheckout;
    }
}
