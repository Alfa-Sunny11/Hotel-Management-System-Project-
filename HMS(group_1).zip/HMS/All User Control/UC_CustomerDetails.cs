﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS.All_User_Control
{
    public partial class UC_CustomerDetails : UserControl
    {
        Function fn = new Function();
        String query;
        public UC_CustomerDetails()
        {
            InitializeComponent();
        }

        private void txtSearchby_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(txtSearchby.SelectedIndex == 0)
            {
                query = "select customer.cid,customer.cname,customer.mobile,customer.nationality,customer.gender,customer.dob,customer.idproof,customer.address,customer.checkin,addroom.roomNo,addroom.roomType,addroom.bed,addroom.price from customer inner join addroom on customer.roomId = addroom.roomId";
                getRecord(query);
            }
            else if(txtSearchby.SelectedIndex ==1)
            {
                query = "select customer.cid,customer.cname,customer.mobile,customer.nationality,customer.gender,customer.dob,customer.idproof,customer.address,customer.checkin,addroom.roomNo,addroom.roomType,addroom.bed,addroom.price from customer inner join addroom on customer.roomId = addroom.roomId where checkout is null";
                getRecord(query);
            }
            else if(txtSearchby.SelectedIndex == 2)
            {
                query = "select customer.cid,customer.cname,customer.mobile,customer.nationality,customer.gender,customer.dob,customer.idproof,customer.address,customer.checkin,customer.checkout,addroom.roomNo,addroom.roomType,addroom.bed,addroom.price from customer inner join addroom on customer.roomId = addroom.roomId where checkout is not null";
                getRecord(query);
            }
        }
        private void getRecord(String query)
        {
            DataSet ds = fn.getData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
