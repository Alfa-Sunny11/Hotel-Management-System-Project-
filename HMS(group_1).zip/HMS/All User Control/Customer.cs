﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.All_User_Control
{
    class Customer
    {
        public string name { get; set; }
        public Int64 chIN { get; set; }
        public Int64 chOut { get; set; }
        public string roomId { get; set; }
    }

}
