﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS.All_User_Control
{
    public partial class UC_Employee : UserControl
    {
        Function fn = new Function();
        String query;
        public UC_Employee()
        {
            InitializeComponent();
        }

        private void gunaLineTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void UC_Employee_Load(object sender, EventArgs e)
        {
            getMaxId();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if(txtName.Text != "" && txtMobile.Text != "" && txtEmail.Text != "" && txtGender.Text != "" && txtIproof.Text != "" && txtDesignation.Text != "" && txtDob.Text != "" && txtSalary.Text != "")
            {
                String name = txtName.Text;
                Int64 mobile = Int64.Parse(txtMobile.Text);
                String email = txtEmail.Text;
                String gender = txtGender.Text;
                String idproof = txtIproof.Text;
                String designation = txtDesignation.Text;
                String dob = txtDob.Text;
                Int64 salary = Int64.Parse(txtSalary.Text);
                getMaxId();
                query = "insert into staff (ename,mobile,gender,email,idproof,designation,dob,salary) values('"+name+"',"+mobile+",'"+gender+"','"+email+"','"+idproof+"','"+designation+"','"+dob+"',"+salary+") ";
                fn.setData(query, "Register Successfully");
                getMaxId();
                clearAll();
            }
            else
            {
                MessageBox.Show("Fill All Fields", "Warning !!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tabEmployee_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabEmployee.SelectedIndex == 1)
            {
                setemployee(gunaDataGridView1);
            }
            else if (tabEmployee.SelectedIndex == 2)
            {
                setemployee(gunaDataGridView2);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(txtid.Text != "")
                 {
                     if(MessageBox.Show("Are yoy Sure","Confirmation ",MessageBoxButtons.YesNo,MessageBoxIcon.Warning) == DialogResult.Yes)
                         {
                              query = "delete from staff where sId = "+txtid.Text+"";
                              fn.setData(query, "Delete Successfully");
                              tabEmployee_SelectedIndexChanged(this, null);
                         }
                 }
           
        }

        private void UC_Employee_Leave(object sender, EventArgs e)
        {
            clearAll();
        }

        public void getMaxId()
        {
            query = "select max(sId) from staff";
            DataSet ds = fn.getData(query);

            if (ds.Tables[0].Rows[0][0].ToString() != "")
            {
                Int64 num = Int64.Parse(ds.Tables[0].Rows[0][0].ToString());
                labelToSet.Text = (num + 1).ToString();
            }
        }

        public void clearAll()
        {
            txtName.Clear();
            txtMobile.Clear();
            txtEmail.Clear();
            txtGender.SelectedIndex = -1;
            txtIproof.Clear();
            txtDesignation.SelectedIndex = -1;
            txtDob.ResetText();
            txtSalary.Clear();
        }

        public void setemployee(DataGridView dgv)
        {
            query = "select * from staff";
            DataSet ds = fn.getData(query);
            dgv.DataSource = ds.Tables[0];
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
