﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS.All_User_Control
{
    public partial class UC_Payment : UserControl
    {
        Function fn = new Function();
        String query;
        public UC_Payment()
        {
            InitializeComponent();
        }

        private void gunaLabel4_Click(object sender, EventArgs e)
        {

        }

        private void btnalloteroom_Click(object sender, EventArgs e)
        {
            if(txtCid.Text != "" && txtTA.Text != "" && txtType.Text != "" && txtAmount.Text != "" && txtPaydate.Text != "")
            {
               
                String Cid = txtCid.Text;
                Int64 TotalAmo = Int64.Parse(txtTA.Text);
                String type = txtType.Text;
                Int64 Amount = Int64.Parse(txtAmount.Text);
                String PayDate = txtPaydate.Text;
                Int64 due = Int64.Parse(txtDue.Text);
                query = "insert into payment (id,totalAmount,type,amount,payDate,remaining) values('" + Cid + "'," + TotalAmo + ",'" + type + "'," + Amount + ",'" + PayDate + "'," + due + " ) ";
                fn.setData(query, "Register Successfully");
                clearAll();
            }
            else
            {
                MessageBox.Show("Fill All Fields", "Warning !!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void UC_Payment_Load(object sender, EventArgs e)
        {
   //         query = "select customer.cid,customer.cname,customer.mobile,customer.nationality,customer.gender,customer.idproof,customer.address,customer.checkin,customer.checkout,payment.id from payment inner join customer on payment.id = customer.idproof ";
    //        DataSet ds = fn.getData(query);
     //       gunaDataGridView1.DataSource = ds.Tables[0];
        }
            


        private void tabPayment_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (tabPayment.SelectedIndex == 1)
            {
                setpayment(gunaDataGridView1);
            }
            else if (tabPayment.SelectedIndex == 2)
            {
                setpayment(gunaDataGridView2);
            }

        }

        

        private void UC_Payment_Leave(object sender, EventArgs e)
        {
            clearAll();
        }

        

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
        //    query = "select customer.cid,customer.cname,customer.mobile,customer.nationality,customer.gender,customer.idproof,customer.address,customer.checkin,customer.checkout,payment.id from payment inner join customer on payment.id = customer.idproof where id like '" + txtSearch.Text + "'";
            query = "select payment.id,payment.totalAmount,payment.type,amount,payment.payDate,payment.remaining from payment where id like '" + txtSearch.Text + "'";
            DataSet ds = fn.getData(query);
            gunaDataGridView1.DataSource = ds.Tables[0];
        }

       
/*
        private void btnDlt_Click(object sender, EventArgs e)
        {
            if (txtCid.Text != "")
            {
                if (MessageBox.Show("Are yoy Sure", "Confirmation ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    query = "delete from payment where sId = " + txtCid.Text + "";
                    fn.setData(query, "Delete Successfully");
                    tabPayment_SelectedIndexChanged_1(this, null);
                }
            }
        }
*/
     

        public void setpayment(DataGridView dgv)
        {
            query = "select * from payment";
            DataSet ds = fn.getData(query);
            dgv.DataSource = ds.Tables[0];
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtid.Text != "")
            {
                if (MessageBox.Show("Are yoy Sure", "Confirmation ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    query = "delete from payment where pId = " + txtid.Text + "";
                    fn.setData(query, "Delete Successfully");
                    tabPayment_SelectedIndexChanged_1(this, null);
                }
            }
        }

        public void clearAll()
        {
            txtCid.Clear();
            txtTA.Clear();
            txtType.SelectedIndex = -1;
            txtAmount.Clear();
            txtPaydate.ResetText();
            txtDue.Clear();
        }

       
    }
}
