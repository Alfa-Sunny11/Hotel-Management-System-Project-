﻿namespace HMS
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.btnMini = new Guna.UI.WinForms.GunaTransfarantPictureBox();
            this.btnExit = new Guna.UI.WinForms.GunaTransfarantPictureBox();
            this.btnAddRoom = new Guna.UI.WinForms.GunaButton();
            this.CustomerReg = new Guna.UI.WinForms.GunaButton();
            this.Checkout = new Guna.UI.WinForms.GunaButton();
            this.CustomerDetails = new Guna.UI.WinForms.GunaButton();
            this.Employee = new Guna.UI.WinForms.GunaButton();
            this.UtiltyInfo = new Guna.UI.WinForms.GunaButton();
            this.gunaElipse2 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse3 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse4 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse5 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse6 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse7 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.btnPayment = new Guna.UI.WinForms.GunaButton();
            this.gunaElipse8 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.uC_Payment1 = new HMS.All_User_Control.UC_Payment();
            this.uC_Blank1 = new HMS.All_User_Control.UC_Blank();
            this.uC_AddRoom3 = new HMS.All_User_Control.UC_AddRoom();
            this.uC_UtilityInfo1 = new HMS.All_User_Control.UC_UtilityInfo();
            this.uC_Employee1 = new HMS.All_User_Control.UC_Employee();
            this.uC_CustomerDetails1 = new HMS.All_User_Control.UC_CustomerDetails();
            this.uC_CustomerCheckOut1 = new HMS.All_User_Control.UC_CustomerCheckOut();
            this.uC_CustomerReg1 = new HMS.All_User_Control.UC_CustomerReg();
            this.uC_AddRoom1 = new HMS.All_User_Control.UC_AddRoom();
            this.uC_Blank2 = new HMS.All_User_Control.UC_Blank();
            ((System.ComponentModel.ISupportInitialize)(this.btnMini)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            this.SuspendLayout();
            // 
            // btnMini
            // 
            this.btnMini.BackColor = System.Drawing.Color.Transparent;
            this.btnMini.BaseColor = System.Drawing.Color.Black;
            this.btnMini.Image = ((System.Drawing.Image)(resources.GetObject("btnMini.Image")));
            this.btnMini.Location = new System.Drawing.Point(1145, 12);
            this.btnMini.Name = "btnMini";
            this.btnMini.Size = new System.Drawing.Size(30, 36);
            this.btnMini.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMini.TabIndex = 2;
            this.btnMini.TabStop = false;
            this.btnMini.Click += new System.EventHandler(this.btnMini_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.BaseColor = System.Drawing.Color.Black;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.Location = new System.Drawing.Point(1182, 13);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(35, 35);
            this.btnExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnExit.TabIndex = 2;
            this.btnExit.TabStop = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAddRoom
            // 
            this.btnAddRoom.AnimationHoverSpeed = 0.07F;
            this.btnAddRoom.AnimationSpeed = 0.03F;
            this.btnAddRoom.BackColor = System.Drawing.Color.Transparent;
            this.btnAddRoom.BaseColor = System.Drawing.Color.Crimson;
            this.btnAddRoom.BorderColor = System.Drawing.Color.Black;
            this.btnAddRoom.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAddRoom.FocusedColor = System.Drawing.Color.Empty;
            this.btnAddRoom.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddRoom.ForeColor = System.Drawing.Color.White;
            this.btnAddRoom.Image = null;
            this.btnAddRoom.ImageSize = new System.Drawing.Size(20, 20);
            this.btnAddRoom.Location = new System.Drawing.Point(36, 88);
            this.btnAddRoom.Name = "btnAddRoom";
            this.btnAddRoom.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.btnAddRoom.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnAddRoom.OnHoverForeColor = System.Drawing.Color.White;
            this.btnAddRoom.OnHoverImage = null;
            this.btnAddRoom.OnPressedColor = System.Drawing.Color.Black;
            this.btnAddRoom.Radius = 25;
            this.btnAddRoom.Size = new System.Drawing.Size(229, 54);
            this.btnAddRoom.TabIndex = 3;
            this.btnAddRoom.Text = "Add Room";
            this.btnAddRoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAddRoom.Click += new System.EventHandler(this.btnAddRoom_Click);
            // 
            // CustomerReg
            // 
            this.CustomerReg.AnimationHoverSpeed = 0.07F;
            this.CustomerReg.AnimationSpeed = 0.03F;
            this.CustomerReg.BackColor = System.Drawing.Color.Transparent;
            this.CustomerReg.BaseColor = System.Drawing.Color.Crimson;
            this.CustomerReg.BorderColor = System.Drawing.Color.Black;
            this.CustomerReg.DialogResult = System.Windows.Forms.DialogResult.None;
            this.CustomerReg.FocusedColor = System.Drawing.Color.Empty;
            this.CustomerReg.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerReg.ForeColor = System.Drawing.Color.White;
            this.CustomerReg.Image = null;
            this.CustomerReg.ImageSize = new System.Drawing.Size(20, 20);
            this.CustomerReg.Location = new System.Drawing.Point(34, 170);
            this.CustomerReg.Name = "CustomerReg";
            this.CustomerReg.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.CustomerReg.OnHoverBorderColor = System.Drawing.Color.Black;
            this.CustomerReg.OnHoverForeColor = System.Drawing.Color.White;
            this.CustomerReg.OnHoverImage = null;
            this.CustomerReg.OnPressedColor = System.Drawing.Color.Black;
            this.CustomerReg.Radius = 25;
            this.CustomerReg.Size = new System.Drawing.Size(229, 54);
            this.CustomerReg.TabIndex = 3;
            this.CustomerReg.Text = "Customer Registration";
            this.CustomerReg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CustomerReg.Click += new System.EventHandler(this.CustomerReg_Click);
            // 
            // Checkout
            // 
            this.Checkout.AnimationHoverSpeed = 0.07F;
            this.Checkout.AnimationSpeed = 0.03F;
            this.Checkout.BackColor = System.Drawing.Color.Transparent;
            this.Checkout.BaseColor = System.Drawing.Color.Crimson;
            this.Checkout.BorderColor = System.Drawing.Color.Black;
            this.Checkout.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Checkout.FocusedColor = System.Drawing.Color.Empty;
            this.Checkout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Checkout.ForeColor = System.Drawing.Color.White;
            this.Checkout.Image = null;
            this.Checkout.ImageSize = new System.Drawing.Size(20, 20);
            this.Checkout.Location = new System.Drawing.Point(36, 347);
            this.Checkout.Name = "Checkout";
            this.Checkout.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.Checkout.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Checkout.OnHoverForeColor = System.Drawing.Color.White;
            this.Checkout.OnHoverImage = null;
            this.Checkout.OnPressedColor = System.Drawing.Color.Black;
            this.Checkout.Radius = 25;
            this.Checkout.Size = new System.Drawing.Size(229, 54);
            this.Checkout.TabIndex = 3;
            this.Checkout.Text = "Check Out";
            this.Checkout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Checkout.Click += new System.EventHandler(this.Checkout_Click);
            // 
            // CustomerDetails
            // 
            this.CustomerDetails.AnimationHoverSpeed = 0.07F;
            this.CustomerDetails.AnimationSpeed = 0.03F;
            this.CustomerDetails.BackColor = System.Drawing.Color.Transparent;
            this.CustomerDetails.BaseColor = System.Drawing.Color.Crimson;
            this.CustomerDetails.BorderColor = System.Drawing.Color.Black;
            this.CustomerDetails.DialogResult = System.Windows.Forms.DialogResult.None;
            this.CustomerDetails.FocusedColor = System.Drawing.Color.Empty;
            this.CustomerDetails.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerDetails.ForeColor = System.Drawing.Color.White;
            this.CustomerDetails.Image = null;
            this.CustomerDetails.ImageSize = new System.Drawing.Size(20, 20);
            this.CustomerDetails.Location = new System.Drawing.Point(36, 424);
            this.CustomerDetails.Name = "CustomerDetails";
            this.CustomerDetails.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.CustomerDetails.OnHoverBorderColor = System.Drawing.Color.Black;
            this.CustomerDetails.OnHoverForeColor = System.Drawing.Color.White;
            this.CustomerDetails.OnHoverImage = null;
            this.CustomerDetails.OnPressedColor = System.Drawing.Color.Black;
            this.CustomerDetails.Radius = 25;
            this.CustomerDetails.Size = new System.Drawing.Size(229, 54);
            this.CustomerDetails.TabIndex = 3;
            this.CustomerDetails.Text = "Customer Details";
            this.CustomerDetails.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CustomerDetails.Click += new System.EventHandler(this.CustomerDetails_Click);
            // 
            // Employee
            // 
            this.Employee.AnimationHoverSpeed = 0.07F;
            this.Employee.AnimationSpeed = 0.03F;
            this.Employee.BackColor = System.Drawing.Color.Transparent;
            this.Employee.BaseColor = System.Drawing.Color.Crimson;
            this.Employee.BorderColor = System.Drawing.Color.Black;
            this.Employee.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Employee.FocusedColor = System.Drawing.Color.Empty;
            this.Employee.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Employee.ForeColor = System.Drawing.Color.White;
            this.Employee.Image = null;
            this.Employee.ImageSize = new System.Drawing.Size(20, 20);
            this.Employee.Location = new System.Drawing.Point(36, 501);
            this.Employee.Name = "Employee";
            this.Employee.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.Employee.OnHoverBorderColor = System.Drawing.Color.Black;
            this.Employee.OnHoverForeColor = System.Drawing.Color.White;
            this.Employee.OnHoverImage = null;
            this.Employee.OnPressedColor = System.Drawing.Color.Black;
            this.Employee.Radius = 25;
            this.Employee.Size = new System.Drawing.Size(229, 54);
            this.Employee.TabIndex = 3;
            this.Employee.Text = "Employee";
            this.Employee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Employee.Click += new System.EventHandler(this.Employee_Click);
            // 
            // UtiltyInfo
            // 
            this.UtiltyInfo.AnimationHoverSpeed = 0.07F;
            this.UtiltyInfo.AnimationSpeed = 0.03F;
            this.UtiltyInfo.BackColor = System.Drawing.Color.Transparent;
            this.UtiltyInfo.BaseColor = System.Drawing.Color.Crimson;
            this.UtiltyInfo.BorderColor = System.Drawing.Color.Black;
            this.UtiltyInfo.DialogResult = System.Windows.Forms.DialogResult.None;
            this.UtiltyInfo.FocusedColor = System.Drawing.Color.Empty;
            this.UtiltyInfo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UtiltyInfo.ForeColor = System.Drawing.Color.White;
            this.UtiltyInfo.Image = null;
            this.UtiltyInfo.ImageSize = new System.Drawing.Size(20, 20);
            this.UtiltyInfo.Location = new System.Drawing.Point(34, 580);
            this.UtiltyInfo.Name = "UtiltyInfo";
            this.UtiltyInfo.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.UtiltyInfo.OnHoverBorderColor = System.Drawing.Color.Black;
            this.UtiltyInfo.OnHoverForeColor = System.Drawing.Color.White;
            this.UtiltyInfo.OnHoverImage = null;
            this.UtiltyInfo.OnPressedColor = System.Drawing.Color.Black;
            this.UtiltyInfo.Radius = 25;
            this.UtiltyInfo.Size = new System.Drawing.Size(229, 54);
            this.UtiltyInfo.TabIndex = 3;
            this.UtiltyInfo.Text = "Utility Info";
            this.UtiltyInfo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.UtiltyInfo.Click += new System.EventHandler(this.UtiltyInfo_Click);
            // 
            // gunaElipse2
            // 
            this.gunaElipse2.Radius = 25;
            this.gunaElipse2.TargetControl = this;
            // 
            // gunaElipse3
            // 
            this.gunaElipse3.Radius = 25;
            this.gunaElipse3.TargetControl = this;
            // 
            // gunaElipse4
            // 
            this.gunaElipse4.Radius = 25;
            this.gunaElipse4.TargetControl = this;
            // 
            // gunaElipse5
            // 
            this.gunaElipse5.Radius = 25;
            this.gunaElipse5.TargetControl = this;
            // 
            // gunaElipse6
            // 
            this.gunaElipse6.Radius = 25;
            this.gunaElipse6.TargetControl = this;
            // 
            // gunaElipse7
            // 
            this.gunaElipse7.Radius = 25;
            this.gunaElipse7.TargetControl = this;
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.Radius = 25;
            this.gunaElipse1.TargetControl = this;
            // 
            // btnPayment
            // 
            this.btnPayment.AnimationHoverSpeed = 0.07F;
            this.btnPayment.AnimationSpeed = 0.03F;
            this.btnPayment.BackColor = System.Drawing.Color.Transparent;
            this.btnPayment.BaseColor = System.Drawing.Color.Crimson;
            this.btnPayment.BorderColor = System.Drawing.Color.Black;
            this.btnPayment.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnPayment.FocusedColor = System.Drawing.Color.Empty;
            this.btnPayment.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayment.ForeColor = System.Drawing.Color.White;
            this.btnPayment.Image = null;
            this.btnPayment.ImageSize = new System.Drawing.Size(20, 20);
            this.btnPayment.Location = new System.Drawing.Point(34, 263);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.OnHoverBaseColor = System.Drawing.Color.Lime;
            this.btnPayment.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnPayment.OnHoverForeColor = System.Drawing.Color.White;
            this.btnPayment.OnHoverImage = null;
            this.btnPayment.OnPressedColor = System.Drawing.Color.Black;
            this.btnPayment.Radius = 25;
            this.btnPayment.Size = new System.Drawing.Size(229, 54);
            this.btnPayment.TabIndex = 13;
            this.btnPayment.Text = "Make Payment";
            this.btnPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // gunaElipse8
            // 
            this.gunaElipse8.Radius = 25;
            this.gunaElipse8.TargetControl = this;
            // 
            // uC_Payment1
            // 
            this.uC_Payment1.BackColor = System.Drawing.Color.Coral;
            this.uC_Payment1.Location = new System.Drawing.Point(292, 98);
            this.uC_Payment1.Name = "uC_Payment1";
            this.uC_Payment1.Size = new System.Drawing.Size(883, 536);
            this.uC_Payment1.TabIndex = 14;
            // 
            // uC_Blank1
            // 
            this.uC_Blank1.BackColor = System.Drawing.Color.Transparent;
            this.uC_Blank1.Location = new System.Drawing.Point(292, 98);
            this.uC_Blank1.Name = "uC_Blank1";
            this.uC_Blank1.Size = new System.Drawing.Size(883, 536);
            this.uC_Blank1.TabIndex = 12;
            // 
            // uC_AddRoom3
            // 
            this.uC_AddRoom3.AccessibleRole = System.Windows.Forms.AccessibleRole.Pane;
            this.uC_AddRoom3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.uC_AddRoom3.Location = new System.Drawing.Point(292, 98);
            this.uC_AddRoom3.Name = "uC_AddRoom3";
            this.uC_AddRoom3.Size = new System.Drawing.Size(883, 536);
            this.uC_AddRoom3.TabIndex = 11;
            this.uC_AddRoom3.UseWaitCursor = true;
            // 
            // uC_UtilityInfo1
            // 
            this.uC_UtilityInfo1.BackColor = System.Drawing.Color.MediumPurple;
            this.uC_UtilityInfo1.Location = new System.Drawing.Point(292, 98);
            this.uC_UtilityInfo1.Name = "uC_UtilityInfo1";
            this.uC_UtilityInfo1.Size = new System.Drawing.Size(883, 536);
            this.uC_UtilityInfo1.TabIndex = 9;
            // 
            // uC_Employee1
            // 
            this.uC_Employee1.BackColor = System.Drawing.Color.IndianRed;
            this.uC_Employee1.Location = new System.Drawing.Point(292, 98);
            this.uC_Employee1.Name = "uC_Employee1";
            this.uC_Employee1.Size = new System.Drawing.Size(883, 536);
            this.uC_Employee1.TabIndex = 8;
            // 
            // uC_CustomerDetails1
            // 
            this.uC_CustomerDetails1.BackColor = System.Drawing.Color.LightGreen;
            this.uC_CustomerDetails1.Location = new System.Drawing.Point(292, 98);
            this.uC_CustomerDetails1.Name = "uC_CustomerDetails1";
            this.uC_CustomerDetails1.Size = new System.Drawing.Size(883, 536);
            this.uC_CustomerDetails1.TabIndex = 7;
            // 
            // uC_CustomerCheckOut1
            // 
            this.uC_CustomerCheckOut1.BackColor = System.Drawing.Color.Pink;
            this.uC_CustomerCheckOut1.Location = new System.Drawing.Point(292, 98);
            this.uC_CustomerCheckOut1.Name = "uC_CustomerCheckOut1";
            this.uC_CustomerCheckOut1.Size = new System.Drawing.Size(883, 536);
            this.uC_CustomerCheckOut1.TabIndex = 6;
            // 
            // uC_CustomerReg1
            // 
            this.uC_CustomerReg1.Location = new System.Drawing.Point(292, 98);
            this.uC_CustomerReg1.Name = "uC_CustomerReg1";
            this.uC_CustomerReg1.Size = new System.Drawing.Size(883, 536);
            this.uC_CustomerReg1.TabIndex = 5;
            // 
            // uC_AddRoom1
            // 
            this.uC_AddRoom1.AccessibleRole = System.Windows.Forms.AccessibleRole.Pane;
            this.uC_AddRoom1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.uC_AddRoom1.Location = new System.Drawing.Point(292, 98);
            this.uC_AddRoom1.Name = "uC_AddRoom1";
            this.uC_AddRoom1.Size = new System.Drawing.Size(883, 536);
            this.uC_AddRoom1.TabIndex = 4;
            this.uC_AddRoom1.UseWaitCursor = true;
            // 
            // uC_Blank2
            // 
            this.uC_Blank2.BackColor = System.Drawing.Color.Transparent;
            this.uC_Blank2.Location = new System.Drawing.Point(292, 98);
            this.uC_Blank2.Name = "uC_Blank2";
            this.uC_Blank2.Size = new System.Drawing.Size(883, 536);
            this.uC_Blank2.TabIndex = 15;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1228, 722);
            this.Controls.Add(this.uC_Blank2);
            this.Controls.Add(this.uC_Payment1);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.uC_Blank1);
            this.Controls.Add(this.uC_AddRoom3);
            this.Controls.Add(this.uC_UtilityInfo1);
            this.Controls.Add(this.uC_Employee1);
            this.Controls.Add(this.uC_CustomerDetails1);
            this.Controls.Add(this.uC_CustomerCheckOut1);
            this.Controls.Add(this.uC_CustomerReg1);
            this.Controls.Add(this.uC_AddRoom1);
            this.Controls.Add(this.UtiltyInfo);
            this.Controls.Add(this.Employee);
            this.Controls.Add(this.CustomerDetails);
            this.Controls.Add(this.Checkout);
            this.Controls.Add(this.CustomerReg);
            this.Controls.Add(this.btnAddRoom);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnMini);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.btnMini)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaTransfarantPictureBox btnMini;
        private Guna.UI.WinForms.GunaTransfarantPictureBox btnExit;
        private Guna.UI.WinForms.GunaButton btnAddRoom;
        private Guna.UI.WinForms.GunaButton CustomerReg;
        private Guna.UI.WinForms.GunaButton Checkout;
        private Guna.UI.WinForms.GunaButton CustomerDetails;
        private Guna.UI.WinForms.GunaButton Employee;
        private Guna.UI.WinForms.GunaButton UtiltyInfo;
        private All_User_Control.UC_AddRoom uC_AddRoom1;
        private All_User_Control.UC_CustomerReg uC_CustomerReg1;
        private Guna.UI.WinForms.GunaElipse gunaElipse2;
        private Guna.UI.WinForms.GunaElipse gunaElipse3;
        private All_User_Control.UC_CustomerCheckOut uC_CustomerCheckOut1;
        private Guna.UI.WinForms.GunaElipse gunaElipse4;
        private All_User_Control.UC_CustomerDetails uC_CustomerDetails1;
        private Guna.UI.WinForms.GunaElipse gunaElipse5;
        private All_User_Control.UC_Employee uC_Employee1;
        private Guna.UI.WinForms.GunaElipse gunaElipse6;
        private All_User_Control.UC_UtilityInfo uC_UtilityInfo1;
        private Guna.UI.WinForms.GunaElipse gunaElipse7;
        private All_User_Control.UC_AddRoom uC_AddRoom3;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private All_User_Control.UC_Blank uC_Blank1;
        private Guna.UI.WinForms.GunaButton btnPayment;
        private Guna.UI.WinForms.GunaElipse gunaElipse8;
        private All_User_Control.UC_Payment uC_Payment1;
        private All_User_Control.UC_Blank uC_Blank2;
    }
}